QORSHAHA MAXAMAD - MASHRUUCA ANDROID

Mashruucan wuxuu ka kooban yahay app Android fudud oo offline ku shaqeeya.
App-ku wuxuu leeyahay 7-da hawlood ee qorshaha, calaamadeyn la taaban karo,
horumar 0/7 ilaa 7/7, kaydin gudaha telefoonka, iyo dib-u-bilaabid marka
maalin cusub timaado.

MUHIIM:
Kani waa SOURCE PROJECT, ma aha APK diyaar u ah rakibid.
APK-ga waxaa lagu dhisaa GitHub Actions:
1. Ku samee GitHub repository cusub.
2. Soo geli dhammaan faylasha mashruucan repository-ga.
3. Fur tab-ka Actions.
4. Dooro "Build Qorshaha Maxamad APK".
5. Riix "Run workflow".
6. Marka build-ku dhammaado, fur natiijada workflow-ga oo ka soo dejiso
   artifact-ka la yiraahdo "Qorshaha-Maxamad-APK".
7. Ka fur ZIP-ka artifact-ka, kadib rakib app-debug.apk telefoonka Android.

APK-ga debug waxaa loogu talagalay tijaabo iyo rakibid gacanta ah. Android
wuxuu ku weydiin karaa oggolaansho lagu rakibo app ka yimid browser/fayl.
